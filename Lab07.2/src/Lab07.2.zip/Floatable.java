public interface Floatable {
    public abstract void fl0at();
}
